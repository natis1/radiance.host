# Infinite Grimm 1.0.1

Infinite Grimm redefines the Nightmare King Grimm fight in Hollow Knight.
Fight NKG a second time in an increasingly difficult endless battle for geo and fun.
Many optional challenge modes including NGG and timed modes.
How long can you dance with fire?

### Features

* Fight Grimm in an endless, increasingly difficult battle.
* Dance and die and live forever with the rhythmic and cathartic normal difficulty.
* Optional hard difficulty to challenge your muscle memory and push your skill to its limits.
* Earn geo and compliments from Grimm based on the damage done.
* Every attack dodgeable at every speed. No more relying on RNG for your hitless run.*
* Bring Grimmchild with you for moral support and extra damage.
* Leave Grimmchild behind for two extra notches.
* Configure Grimm to your liking. He can fight as slowly or quickly as you wish.
* See your current score at all times. Just look at your geo counter (Thanks to 56 for this)
* Time attack mode - Six minutes (by default) to prove your skills.
* One hit mode to get the adrenaline pumping. Also enables FotF for extra damage.
* Your worst nemesis returns with Infinite Nightmare God Grimms. They're just as you remembered but no downpatch needed.
* Rewrites Hollow Knight lore. Fully compatible with Redwing lore though.

†Assumes every movement ability unlocked. Undodgeable attacks are treated as severe bugs.

### How to install

This mod depends on:

Hollow Knight Lifeblood (tested on regular and beta branch)

[Modding API](https://github.com/seanpr96/HollowKnight.Modding) by Wyza, Firzen, and Seanpr
For copyright reasons prebuilt binaries of this are not available publicly.
See the Hollow Knight Discord or the mods google drive folder.

[ModCommon](https://github.com/Kerr1291/ModCommon) by Kerr1291.

So first install these from the drive or from the modinstaller https://github.com/Ayugradow/ModInstaller/releases/

Then move infinitegrimm.dll to `<Path-To-Hollow Knight>\Hollow Knight\hollow_knight_Data\Managed\Mods`

For meaningful progression, it's worth installing this mod alongside [Grimmchild Upgrades](https://github.com/natis1/grimmchildupgrades)

---

Note about copyright:

This mod is licensed under the Gnu Public License Version 3. A copy of the source code is available here:
https://github.com/natis1/infinitegrimm

---

Special thanks: Basically everyone who has ever made a hollow knight mod for helping me out with my first (second?) C# project.

Especially:
56 for the geo display code
KDT for the NGG code.

---

Bugs:
Please report any bugs or issues or feature requests to:
https://gitlab.com/natis1/infinitegrimm/issues
